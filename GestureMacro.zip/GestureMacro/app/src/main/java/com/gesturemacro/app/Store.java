package com.gesturemacro.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/** All settings and saved gestures live here (one SharedPreferences file shared by the app and the service). */
public final class Store {
    private Store() {}

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("gesture_macro", Context.MODE_PRIVATE);
    }

    public static boolean b(Context c, String k, boolean d) { return prefs(c).getBoolean(k, d); }
    public static void setB(Context c, String k, boolean v) { prefs(c).edit().putBoolean(k, v).apply(); }
    public static int i(Context c, String k, int d) { return prefs(c).getInt(k, d); }
    public static void setI(Context c, String k, int v) { prefs(c).edit().putInt(k, v).apply(); }
    public static float f(Context c, String k, float d) { return prefs(c).getFloat(k, d); }
    public static void setF(Context c, String k, float v) { prefs(c).edit().putFloat(k, v).apply(); }
    public static String s(Context c, String k, String d) { return prefs(c).getString(k, d); }
    public static void setS(Context c, String k, String v) { prefs(c).edit().putString(k, v).apply(); }

    // ---------------------------------------------------------------- actions

    public static final String[] ACTION_IDS = {
            "none", "menu", "home", "back", "recents", "notifications", "quick_settings",
            "lock", "screenshot", "power", "vol_up", "vol_down", "mute"};
    public static final String[] ACTION_LABELS = {
            "None", "Open Menu", "Home", "Back", "Recent Apps", "Notifications", "Quick Settings",
            "Lock Screen", "Screenshot", "Power Menu", "Volume Up", "Volume Down", "Mute"};

    public static String actionLabel(Context c, String id) {
        for (int n = 0; n < ACTION_IDS.length; n++) {
            if (ACTION_IDS[n].equals(id)) return ACTION_LABELS[n];
        }
        if (id != null && id.startsWith("macro:")) {
            Macro m = findMacro(c, id.substring(6));
            if (m != null) return m.name;
        }
        return "None";
    }

    // ---------------------------------------------------------------- top level menu

    public static final String[] MENU_KEYS = {"custom", "notifications", "device", "gestures", "home", "control"};
    public static final String[] MENU_LABELS = {"Custom", "Notification Center", "Device", "Gestures", "Home", "Control Center"};

    public static List<String> menuItems(Context c) {
        String raw = s(c, "menu_items", "custom,notifications,device,gestures,home,control");
        List<String> out = new ArrayList<>();
        for (String k : MENU_KEYS) {
            if (("," + raw + ",").contains("," + k + ",")) out.add(k);
        }
        if (out.isEmpty()) out.add("custom");
        return out;
    }

    public static void setMenuItem(Context c, String key, boolean on) {
        List<String> cur = menuItems(c);
        if (on && !cur.contains(key)) cur.add(key);
        if (!on) cur.remove(key);
        StringBuilder sb = new StringBuilder();
        for (String k : MENU_KEYS) {
            if (cur.contains(k)) {
                if (sb.length() > 0) sb.append(',');
                sb.append(k);
            }
        }
        if (sb.length() == 0) sb.append("custom");
        setS(c, "menu_items", sb.toString());
    }

    // ---------------------------------------------------------------- saved gestures

    public static List<Macro> loadMacros(Context c) {
        List<Macro> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(s(c, "macros", "[]"));
            for (int n = 0; n < a.length(); n++) out.add(Macro.fromJson(a.getJSONObject(n)));
        } catch (Exception ignored) {
        }
        return out;
    }

    public static void saveMacros(Context c, List<Macro> list) {
        try {
            JSONArray a = new JSONArray();
            for (Macro m : list) a.put(m.toJson());
            setS(c, "macros", a.toString());
        } catch (Exception ignored) {
        }
    }

    public static void addMacro(Context c, Macro m) {
        List<Macro> l = loadMacros(c);
        l.add(m);
        saveMacros(c, l);
    }

    public static Macro findMacro(Context c, String id) {
        for (Macro m : loadMacros(c)) {
            if (m.id.equals(id)) return m;
        }
        return null;
    }
}
